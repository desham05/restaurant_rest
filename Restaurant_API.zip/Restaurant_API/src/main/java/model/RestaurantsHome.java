package main.java.model;
// Generated 20 Apr, 2018 1:51:23 PM by Hibernate Tools 3.6.0.Final

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class Restaurants.
 * @see com.org.generated.Restaurants
 * @author Hibernate Tools
 */
public class RestaurantsHome {

	private static final Log log = LogFactory.getLog(RestaurantsHome.class);

	private final SessionFactory sessionFactory = getSessionFactory();

	protected SessionFactory getSessionFactory() {
		try {
			return (SessionFactory) new InitialContext().lookup("SessionFactory");
		} catch (Exception e) {
			log.error("Could not locate SessionFactory in JNDI", e);
			throw new IllegalStateException("Could not locate SessionFactory in JNDI");
		}
	}

	public void persist(Restaurants transientInstance) {
		log.debug("persisting Restaurants instance");
		try {
			sessionFactory.getCurrentSession().persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void attachDirty(Restaurants instance) {
		log.debug("attaching dirty Restaurants instance");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Restaurants instance) {
		log.debug("attaching clean Restaurants instance");
		try {
			sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(Restaurants persistentInstance) {
		log.debug("deleting Restaurants instance");
		try {
			sessionFactory.getCurrentSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Restaurants merge(Restaurants detachedInstance) {
		log.debug("merging Restaurants instance");
		try {
			Restaurants result = (Restaurants) sessionFactory.getCurrentSession().merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public Restaurants findById(java.lang.Integer id) {
		log.debug("getting Restaurants instance with id: " + id);
		try {
			Restaurants instance = (Restaurants) sessionFactory.getCurrentSession().get("com.org.generated.Restaurants",
					id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<Restaurants> findByExample(Restaurants instance) {
		log.debug("finding Restaurants instance by example");
		try {
			List<Restaurants> results = (List<Restaurants>) sessionFactory.getCurrentSession()
					.createCriteria("com.org.generated.Restaurants").add(create(instance)).list();
			log.debug("find by example successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
}
