package main.java.constants;

public class ProjectConstants {

	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";
}
